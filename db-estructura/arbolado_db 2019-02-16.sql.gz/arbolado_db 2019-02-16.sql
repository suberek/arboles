-- phpMyAdmin SQL Dump
-- version 4.7.2
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Tiempo de generación: 17-02-2019 a las 04:01:04
-- Versión del servidor: 10.1.26-MariaDB
-- Versión de PHP: 7.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `arbolado_github`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `t_especies`
--

DROP TABLE IF EXISTS `t_especies`;
CREATE TABLE `t_especies` (
  `id` int(11) NOT NULL,
  `nombre_cientifico` varchar(255) NOT NULL DEFAULT '',
  `nombre_comun` varchar(255) NOT NULL DEFAULT '',
  `familia_id` int(11) NOT NULL,
  `tipo_id` int(11) NOT NULL DEFAULT '0',
  `origen` varchar(255) NOT NULL DEFAULT '',
  `region_pampeana` tinyint(1) NOT NULL DEFAULT '0',
  `region_nea` tinyint(1) NOT NULL DEFAULT '0',
  `region_noa` tinyint(1) NOT NULL DEFAULT '0',
  `region_cuyana` tinyint(1) NOT NULL DEFAULT '0',
  `region_patagonica` tinyint(1) NOT NULL DEFAULT '0',
  `procedencia_exotica` varchar(255) DEFAULT NULL,
  `icono` varchar(50) DEFAULT NULL,
  `img_completo` varchar(50) DEFAULT NULL,
  `img_hoja` varchar(50) DEFAULT NULL,
  `img_flor` varchar(50) DEFAULT NULL,
  `img_fruto` varchar(50) DEFAULT NULL,
  `img_fenologia` varchar(50) DEFAULT NULL,
  `descripcion` text,
  `medicinal` text,
  `comestible` text,
  `fauna_asociada` text,
  `magnitud` varchar(255) DEFAULT NULL,
  `forma` varchar(255) DEFAULT NULL,
  `crecimiento` int(11) DEFAULT NULL,
  `follaje` varchar(255) DEFAULT NULL,
  `flor` varchar(255) DEFAULT NULL,
  `fruto` varchar(255) DEFAULT NULL,
  `asoleamiento` int(11) DEFAULT NULL,
  `clima` varchar(255) DEFAULT NULL,
  `suelo` varchar(255) DEFAULT NULL,
  `riego` int(11) DEFAULT NULL,
  `biblio_img_fuentes` text,
  `url` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Truncar tablas antes de insertar `t_especies`
--

TRUNCATE TABLE `t_especies`;
--
-- Volcado de datos para la tabla `t_especies`
--

INSERT INTO `t_especies` (`id`, `nombre_cientifico`, `nombre_comun`, `familia_id`, `tipo_id`, `origen`, `region_pampeana`, `region_nea`, `region_noa`, `region_cuyana`, `region_patagonica`, `procedencia_exotica`, `icono`, `img_completo`, `img_hoja`, `img_flor`, `img_fruto`, `img_fenologia`, `descripcion`, `medicinal`, `comestible`, `fauna_asociada`, `magnitud`, `forma`, `crecimiento`, `follaje`, `flor`, `fruto`, `asoleamiento`, `clima`, `suelo`, `riego`, `biblio_img_fuentes`, `url`) VALUES
(-2, 'No determinable', 'No determinable', 46, 0, 'No determinado', 0, 0, 0, 0, 0, '', 'marker-sin-especie.png', '0', '0', '0', NULL, NULL, NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 'no-determinable -2'),
(-1, 'No determinado', 'No determinado', 46, 0, 'No determinado', 0, 0, 0, 0, 0, '', 'marker-sin-especie.png', '0', '0', '0', NULL, NULL, NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 'no-determinado -1'),
(1, 'Fraxinus pennsylvanica', 'Fresno americano', 47, 1, 'Exótico', 0, 0, 0, 0, 0, 'EEUU y Canada, región oriental', '', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 'fraxinus-pennsylvanica'),
(2, 'Platanus x acerifolia', 'Plátano', 52, 1, 'Exótico', 0, 0, 0, 0, 0, '', '', '0', '0', '0', NULL, NULL, NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 'platanus-x-acerifolia'),
(3, 'Melia azeradach', 'Paraíso', 39, 1, 'Exótico', 0, 0, 0, 0, 0, '', '', '0', '0', '0', NULL, NULL, NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 'melia-azedarach'),
(4, 'Tilia viridis subsp. x moltkei', 'Tilo', 70, 1, 'Exótico', 0, 0, 0, 0, 0, '', '', '0', '0', '0', NULL, NULL, NULL, 'Sí', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 'tilia-viridis-subsp-x-moltkei'),
(111, 'Acacia caven', 'Aromo, Espinillo', 35, 1, 'Nativo/Autóctono', 1, 1, 1, 1, 0, NULL, 'marker-amarillo.png', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'acacia-caven');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `t_familias`
--

DROP TABLE IF EXISTS `t_familias`;
CREATE TABLE `t_familias` (
  `id` int(11) NOT NULL,
  `familia` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Truncar tablas antes de insertar `t_familias`
--

TRUNCATE TABLE `t_familias`;
--
-- Volcado de datos para la tabla `t_familias`
--

INSERT INTO `t_familias` (`id`, `familia`) VALUES
(1, 'Aceraceae'),
(2, 'Adoxaceae'),
(3, 'Agavaceae'),
(4, 'Anacardiáceas'),
(5, 'Apocynaceae'),
(6, 'Aquifoliaceas'),
(7, 'Araliaceas'),
(8, 'Araucariaceas'),
(9, 'Arecaceas'),
(10, 'Asteraceae'),
(11, 'Betuláceas'),
(12, 'Bignoniáceas'),
(13, 'Bombacáceas'),
(14, 'Borragináceas'),
(15, 'Buxaceas'),
(16, 'Caprifoliaceas'),
(17, 'Casuarinaceas'),
(18, 'Celtidacea'),
(19, 'Cephalotaxaceae'),
(20, 'Cervantesiaceae'),
(21, 'Cicadaceas'),
(22, 'Combretaceae'),
(23, 'Cupresáceas'),
(24, 'Ebenaceas'),
(25, 'Eleagnaceas'),
(26, 'Esterculiáceas'),
(27, 'Euforbiáceas'),
(28, 'Fagáceas'),
(29, 'Fitolacáceas'),
(30, 'Ginkgoaceas'),
(31, 'Hamamelidáceas'),
(32, 'Hipocastanáceas'),
(33, 'Juglandáceas'),
(34, 'Lauráceas'),
(35, 'Fabaceae'),
(36, 'Litráceas'),
(37, 'Magnoliáceas'),
(38, 'Malvácea'),
(39, 'Meliáceas'),
(40, 'Menispermaceas'),
(41, 'Mioporaceas'),
(42, 'Mirtáceas'),
(43, 'Moráceas'),
(44, 'Musaceae'),
(45, 'Myrsinaceae'),
(46, 'No identificada'),
(47, 'Oleáceas'),
(48, 'Palmaceas'),
(49, 'Paulowniaceae'),
(50, 'Pináceas'),
(51, 'Pitosporáceas'),
(52, 'Platanaceae'),
(53, 'Podocarpaceae'),
(54, 'Polygonaceas'),
(55, 'Proteáceas'),
(56, 'Punicaceas'),
(57, 'Ramnaceas'),
(58, 'Rosáceas'),
(59, 'Rubiaceae'),
(60, 'Ruscaceae'),
(61, 'Rutaceas'),
(62, 'Salicáceas'),
(63, 'Sapindaceae'),
(64, 'Simarrubáceas'),
(65, 'Solanaceas'),
(66, 'Sterculiaceae'),
(67, 'Taxaceae'),
(68, 'Taxodiáceas'),
(69, 'Teaceae'),
(70, 'Tiliaceas'),
(71, 'Ulmaceas'),
(72, 'Verbenaceas'),
(73, 'Annonaceae'),
(74, 'Cactaceae'),
(75, 'Iridaceae');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `t_fuentes`
--

DROP TABLE IF EXISTS `t_fuentes`;
CREATE TABLE `t_fuentes` (
  `id` int(11) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `descripcion` text,
  `email` varchar(50) DEFAULT NULL,
  `facebook` varchar(255) DEFAULT NULL,
  `twitter` varchar(50) DEFAULT NULL,
  `instagram` varchar(50) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Truncar tablas antes de insertar `t_fuentes`
--

TRUNCATE TABLE `t_fuentes`;
--
-- Volcado de datos para la tabla `t_fuentes`
--

INSERT INTO `t_fuentes` (`id`, `nombre`, `descripcion`, `email`, `facebook`, `twitter`, `instagram`, `url`) VALUES
(1, 'GCBA - Censo de Arbolado de alineación', 'Productor: Ministerio de Modernización - Unidad de Sistemas de Información Geográfica\r\nFuente del dato: Ministerio de Ambiente y Espacio Público-SS Mantenimiento del Espacio Público-DG Arbolado', NULL, 'https://www.facebook.com/BAinnovacion/', NULL, NULL, 'http://data.buenosaires.gob.ar/dataset/arbolado-publico-lineal'),
(2, 'GCBA - Censo de Arbolado en espacios verdes', 'Productor: Ministerio de Modernización - Unidad de Sistemas de Información Geográfica\nFuente del dato: Ministerio de Ambiente y Espacio Público-SS Mantenimiento del Espacio Público-DG Arbolado', NULL, 'https://www.facebook.com/BAinnovacion/', NULL, NULL, 'http://data.buenosaires.gob.ar/dataset/arbolado-en-espacios-verdes'),
(3, 'La ciudad nos regala sabores', 'Mapa de árboles frutales, utilizados para infusiones y medicinales, entre otros. La Ciudad nos regala sabores es un proyecto de <strong>Ludmila Medina</strong>.\nP&aacute;gina de facebook en donde cualquiera puede reportar la ubicaci&oacute;n de un &aacute;rbol con inter&eacute;s en su cosecha: <a href=\"https://www.facebook.com/LaCiudadNosRegalaSabores\" target=\"_blank\">https://www.facebook.com/LaCiudadNosRegalaSabores</a>\n\nListado de &aacute;rboles recolectados por el proyecto: <a href=\"http://tinyurl.com/frutasenlaciudad\" target=\"_blank\">http://tinyurl.com/frutasenlaciudad</a>\n\nMapa por Manuchis: <a href=\"http://arbolesciudad.com.ar/\" target=\"_blank\">http://arbolesciudad.com.ar/</a>', 'lmedina@agro.uba.ar', 'https://www.facebook.com/LaCiudadNosRegalaSabores', NULL, NULL, 'https://www.facebook.com/LaCiudadNosRegalaSabores/'),
(4, 'Martín Simonyan', 'Desarrollador del sitio www.arboladourbano.com', 'martin@simonyan.com.ar', 'https://www.facebook.com/arboladourbanomapa/', 'https://twitter.com/arboladomapa', 'https://www.instagram.com/arbolado.urbano/', 'http://martinsimonyan.com/arboles-de-buenos-aires/'),
(38, 'El Renacer de la Laguna FVET UBA', 'Colaborador', 'elrenacerdelalaguna@gmail.com', 'https://www.facebook.com/elrenacerdelalaguna/', NULL, NULL, NULL),
(50, 'Ciudad Botánica', 'Colaborador', NULL, 'https://www.facebook.com/ciudadbotanica/', NULL, NULL, 'http://www.ciudadbotanica.net/'),
(56, 'Ecoaldea Velatropa', 'Colaborador', 'vamontero@gmail.com', 'https://www.facebook.com/velatropa/', NULL, NULL, 'http://www.velatropa.org');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `t_registros`
--

DROP TABLE IF EXISTS `t_registros`;
CREATE TABLE `t_registros` (
  `id` int(11) NOT NULL,
  `arbol_id` int(11) NOT NULL DEFAULT '0',
  `especie_id` int(11) NOT NULL,
  `lat` float(12,10) NOT NULL,
  `lng` float(12,10) NOT NULL,
  `localidad` varchar(50) NOT NULL DEFAULT 'CABA',
  `calle` varchar(255) DEFAULT NULL,
  `calle_altura` int(11) DEFAULT NULL,
  `espacio_verde` varchar(255) DEFAULT NULL,
  `altura` decimal(6,2) DEFAULT NULL,
  `diametro` decimal(6,2) DEFAULT NULL,
  `inclinacion` int(11) DEFAULT NULL,
  `estado_fitosanitario` varchar(50) DEFAULT NULL,
  `etapa_desarrollo` varchar(50) DEFAULT NULL,
  `fuente_id` int(11) NOT NULL,
  `fecha_creacion` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `removido` varchar(50) DEFAULT NULL,
  `streetview` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Truncar tablas antes de insertar `t_registros`
--

TRUNCATE TABLE `t_registros`;
--
-- Volcado de datos para la tabla `t_registros`
--

INSERT INTO `t_registros` (`id`, `arbol_id`, `especie_id`, `lat`, `lng`, `localidad`, `calle`, `calle_altura`, `espacio_verde`, `altura`, `diametro`, `inclinacion`, `estado_fitosanitario`, `etapa_desarrollo`, `fuente_id`, `fecha_creacion`, `removido`, `streetview`) VALUES
(1, 1, 1, -34.6200256348, -58.3890571594, 'CABA', 'Calvo, Carlos', 1609, '', '7.00', '20.00', 17, NULL, NULL, 1, '2014-07-27 00:00:00', NULL, NULL),
(2, 2, 1, -34.6200332642, -58.3892097473, 'CABA', 'Calvo, Carlos', 1617, '', '8.00', '33.00', 16, NULL, NULL, 1, '2014-07-27 00:00:00', NULL, NULL),
(5, 5, 1, -34.6200561523, -58.3896064758, 'CABA', 'Calvo, Carlos', 1655, '', '6.00', '13.00', 14, NULL, NULL, 1, '2014-07-27 00:00:00', NULL, NULL),
(7, 7, 1, -34.6200637817, -58.3897399902, 'CABA', 'Calvo, Carlos', 0, '', '17.00', '43.00', 10, NULL, NULL, 1, '2014-07-27 00:00:00', NULL, NULL),
(8, 8, 1, -34.6200675964, -58.3898315430, 'CABA', 'Calvo, Carlos', 1673, '', '10.00', '24.00', 10, NULL, NULL, 1, '2014-07-27 00:00:00', NULL, NULL),
(9, 9, 1, -34.6200752258, -58.3899116516, 'CABA', 'Calvo, Carlos', 0, '', '6.00', '17.00', 21, NULL, NULL, 1, '2014-07-27 00:00:00', NULL, NULL),
(10, 10, 1, -34.6200180054, -58.3901634216, 'CABA', 'Solis', 994, '', '15.00', '29.00', 0, NULL, NULL, 1, '2014-07-27 00:00:00', NULL, NULL),
(12, 12, 1, -34.6198272705, -58.3901748657, 'CABA', 'Solis', 0, '', '5.00', '9.00', 0, NULL, NULL, 1, '2014-07-27 00:00:00', NULL, NULL),
(13, 13, 1, -34.6197700500, -58.3901748657, 'CABA', 'Solis', 974, '', '9.00', '23.00', 10, NULL, NULL, 1, '2014-07-27 00:00:00', NULL, NULL),
(14, 14, 1, -34.6197013855, -58.3901786804, 'CABA', 'Solis', 966, '', '3.00', '6.00', 0, NULL, NULL, 1, '2014-07-27 00:00:00', NULL, NULL),
(15, 15, 1, -34.6196212769, -58.3901863098, 'CABA', 'Solis', 960, '', '14.00', '35.00', 0, NULL, NULL, 1, '2014-07-27 00:00:00', NULL, NULL),
(16, 16, 1, -34.6195106506, -58.3901901245, 'CABA', 'Solis', 950, '', '8.00', '13.00', 10, NULL, NULL, 1, '2014-07-27 00:00:00', NULL, NULL),
(17, 17, 1, -34.6194267273, -58.3901939392, 'CABA', 'Solis', 940, '', '19.00', '25.00', 0, NULL, NULL, 1, '2014-07-27 00:00:00', NULL, NULL),
(18, 18, 1, -34.6193580627, -58.3901977539, 'CABA', 'Solis', 930, '', '7.00', '17.00', 13, NULL, NULL, 1, '2014-07-27 00:00:00', NULL, NULL),
(19, 19, 1, -34.6193084717, -58.3902015686, 'CABA', 'Solis', 926, '', '13.00', '24.00', 12, NULL, NULL, 1, '2014-07-27 00:00:00', NULL, NULL),
(20, 20, 1, -34.6192169189, -58.3902053833, 'CABA', 'Solis', 924, '', '14.00', '30.00', 9, NULL, NULL, 1, '2014-07-27 00:00:00', NULL, NULL),
(21, 21, 1, -34.6191520691, -58.3902091980, 'CABA', 'Solis', 912, '', '4.00', '8.00', 0, NULL, NULL, 1, '2014-07-27 00:00:00', NULL, NULL),
(22, 22, 1, -34.6190147400, -58.3901329041, 'CABA', 'Estados Unidos', 0, '', '13.00', '35.00', 0, NULL, NULL, 1, '2014-07-27 00:00:00', NULL, NULL),
(23, 23, 1, -34.6190071106, -58.3900413513, 'CABA', 'Estados Unidos', 1690, '', '7.00', '31.00', 9, NULL, NULL, 1, '2014-07-27 00:00:00', NULL, NULL),
(24, 24, 1, -34.6189994812, -58.3899230957, 'CABA', 'Estados Unidos', 1680, '', '14.00', '39.00', 16, NULL, NULL, 1, '2014-07-27 00:00:00', NULL, NULL),
(25, 25, 1, -34.6189918518, -58.3898315430, 'CABA', 'Estados Unidos', 1666, '', '7.00', '19.00', 24, NULL, NULL, 1, '2014-07-27 00:00:00', NULL, NULL),
(428516, 428516, 111, -34.5933532715, -58.4765930176, 'CABA', 'Av. Chorroarin', NULL, NULL, '1.50', '0.50', 0, 'Sano', 'Joven', 38, '2018-12-10 00:59:32', NULL, NULL),
(428517, 428517, 111, -34.5933074951, -58.4765777588, 'CABA', 'Av. Chorroarin', NULL, NULL, '1.50', '0.50', 0, 'Sano', 'Joven', 38, '2018-12-10 00:59:32', NULL, NULL),
(428518, 428518, 111, -34.5932655334, -58.4765586853, 'CABA', 'Av. Chorroarin', NULL, NULL, '1.50', '0.50', 0, 'Sano', 'Joven', 38, '2018-12-10 00:59:32', NULL, NULL),
(428519, 428519, 111, -34.5932159424, -58.4765434265, 'CABA', 'Av. Chorroarin', NULL, NULL, '1.50', '0.50', 0, 'Sano', 'Joven', 38, '2018-12-10 00:59:32', NULL, NULL),
(428520, 428520, 111, -34.5931663513, -58.4765243530, 'CABA', 'Av. Chorroarin', NULL, NULL, '1.50', '0.50', 0, 'Sano', 'Joven', 38, '2018-12-10 00:59:32', NULL, NULL),
(428521, 428521, 111, -34.5931129456, -58.4765090942, 'CABA', 'Av. Chorroarin', NULL, NULL, '1.50', '0.50', 0, 'Sano', 'Joven', 38, '2018-12-10 00:59:32', NULL, NULL),
(428522, 428522, 111, -34.5940017700, -58.4768295288, 'CABA', 'Av. Chorroarin', NULL, NULL, '1.50', '0.50', 0, 'Sano', 'Joven', 38, '2018-12-10 00:59:32', NULL, NULL),
(428523, 428523, 111, -34.5939598083, -58.4768180847, 'CABA', 'Av. Chorroarin', NULL, NULL, '1.50', '0.50', 0, 'Sano', 'Joven', 38, '2018-12-10 00:59:32', NULL, NULL),
(428524, 428524, 111, -34.5939178467, -58.4767990112, 'CABA', 'Av. Chorroarin', NULL, NULL, '1.50', '0.50', 0, 'Sano', 'Joven', 38, '2018-12-10 00:59:32', NULL, NULL),
(428525, 428525, 111, -34.5938720703, -58.4767837524, 'CABA', 'Av. Chorroarin', NULL, NULL, '1.50', '0.50', 0, 'Sano', 'Joven', 38, '2018-12-10 00:59:32', NULL, NULL),
(428526, 428526, 111, -34.5938301086, -58.4767646790, 'CABA', 'Av. Chorroarin', NULL, NULL, '1.50', '0.50', 0, 'Sano', 'Joven', 38, '2018-12-10 00:59:32', NULL, NULL),
(428527, 428527, 111, -34.5937919617, -58.4767494202, 'CABA', 'Av. Chorroarin', NULL, NULL, '1.50', '0.50', 0, 'Sano', 'Joven', 38, '2018-12-10 00:59:33', NULL, NULL),
(428528, 428528, 111, -34.5937461853, -58.4767341614, 'CABA', 'Av. Chorroarin', NULL, NULL, '1.50', '0.50', 0, 'Sano', 'Joven', 38, '2018-12-10 00:59:33', NULL, NULL),
(428529, 428529, 111, -34.5946235657, -58.4770469666, 'CABA', 'Av. Chorroarin', NULL, NULL, '1.50', '0.50', 0, 'Sano', 'Joven', 38, '2018-12-10 00:59:33', NULL, NULL),
(428530, 428530, 111, -34.5945739746, -58.4770355225, 'CABA', 'Av. Chorroarin', NULL, NULL, '1.50', '0.50', 0, 'Sano', 'Joven', 38, '2018-12-10 00:59:33', NULL, NULL),
(428531, 428531, 111, -34.5945243835, -58.4770126343, 'CABA', 'Av. Chorroarin', NULL, NULL, '1.50', '0.50', 0, 'Sano', 'Joven', 38, '2018-12-10 00:59:33', NULL, NULL),
(428532, 428532, 111, -34.5944709778, -58.4769935608, 'CABA', 'Av. Chorroarin', NULL, NULL, '1.50', '0.50', 0, 'Sano', 'Joven', 38, '2018-12-10 00:59:33', NULL, NULL),
(428533, 428533, 111, -34.5944099426, -58.4769783020, 'CABA', 'Av. Chorroarin', NULL, NULL, '1.50', '0.50', 0, 'Sano', 'Joven', 38, '2018-12-10 00:59:33', NULL, NULL),
(428534, 428534, 111, -34.5943489075, -58.4769515991, 'CABA', 'Av. Chorroarin', NULL, NULL, '1.50', '0.50', 0, 'Sano', 'Joven', 38, '2018-12-10 00:59:33', NULL, NULL),
(428535, 428535, 111, -34.5947074890, -58.4770812988, 'CABA', 'Av. Chorroarin', NULL, NULL, '1.50', '0.50', 0, 'Sano', 'Joven', 38, '2018-12-10 00:59:33', NULL, NULL),
(428536, 428536, 111, -34.5950469971, -58.4771995544, 'CABA', 'Av. Chorroarin', NULL, NULL, '1.50', '0.50', 0, 'Sano', 'Joven', 38, '2018-12-10 00:59:33', NULL, NULL),
(428537, 428537, 111, -34.5949974060, -58.4771842957, 'CABA', 'Av. Chorroarin', NULL, NULL, '1.50', '0.50', 0, 'Sano', 'Joven', 38, '2018-12-10 00:59:33', NULL, NULL),
(428538, 428538, 111, -34.5949440002, -58.4771652222, 'CABA', 'Av. Chorroarin', NULL, NULL, '1.50', '0.50', 0, 'Sano', 'Joven', 38, '2018-12-10 00:59:33', NULL, NULL),
(428539, 428539, 111, -34.5948867798, -58.4771423340, 'CABA', 'Av. Chorroarin', NULL, NULL, '1.50', '0.50', 0, 'Sano', 'Joven', 38, '2018-12-10 00:59:33', NULL, NULL),
(428540, 428540, 111, -34.5948257446, -58.4771232605, 'CABA', 'Av. Chorroarin', NULL, NULL, '1.50', '0.50', 0, 'Sano', 'Joven', 38, '2018-12-10 00:59:33', NULL, NULL),
(428541, 1, 1, -34.6200256348, -58.3890571594, 'CABA', 'Calvo, Carlos', 1609, '', '15.00', '25.00', 17, NULL, NULL, 4, '2019-02-16 00:00:00', NULL, NULL),
(428542, 2, 1, -34.6200332642, -58.3892097473, 'CABA', 'Calvo, Carlos', 1617, '', '8.00', '33.00', 16, NULL, NULL, 1, '2014-07-27 00:00:00', 'motivo desconocido (ejemplo)', NULL),
(428543, 1, 4, -34.6200256348, -58.3890571594, 'CABA', 'Calvo, Carlos', 1609, '', '15.00', '25.00', 17, NULL, NULL, 4, '2019-02-17 00:00:00', NULL, 'https://www.google.com/maps/embed?pb=!4v1550372352073!6m8!1m7!1sb7zxZPWllG8cXJI9hlQBeA!2m2!1d-34.62006183791388!2d-58.38903648914669!3f327.22968348112414!4f1.4369905584968308!5f1.1924812503605782');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `t_tipos`
--

DROP TABLE IF EXISTS `t_tipos`;
CREATE TABLE `t_tipos` (
  `id` int(11) NOT NULL,
  `tipo` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Truncar tablas antes de insertar `t_tipos`
--

TRUNCATE TABLE `t_tipos`;
--
-- Volcado de datos para la tabla `t_tipos`
--

INSERT INTO `t_tipos` (`id`, `tipo`) VALUES
(0, 'Dato no ingresado'),
(1, 'Árbol latifoliado caducifolio'),
(2, 'Árbol latifoliado perennifolio'),
(4, 'Árbol conífero caducifolio'),
(5, 'Árbol conífero perennifolio'),
(6, 'Palmera'),
(7, 'Arbusto caducifolio'),
(11, 'Árbol latifoliado semipersistente');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `t_especies`
--
ALTER TABLE `t_especies`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `url` (`url`),
  ADD UNIQUE KEY `nombre_cientifico` (`nombre_cientifico`),
  ADD KEY `id_especie` (`id`),
  ADD KEY `id_familia` (`familia_id`),
  ADD KEY `tipo_id` (`tipo_id`);

--
-- Indices de la tabla `t_familias`
--
ALTER TABLE `t_familias`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indices de la tabla `t_fuentes`
--
ALTER TABLE `t_fuentes`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `t_registros`
--
ALTER TABLE `t_registros`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_individuo` (`id`),
  ADD KEY `arbol_id` (`arbol_id`),
  ADD KEY `id_especie` (`especie_id`),
  ADD KEY `id_usuario` (`fuente_id`);

--
-- Indices de la tabla `t_tipos`
--
ALTER TABLE `t_tipos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `t_especies`
--
ALTER TABLE `t_especies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=112;
--
-- AUTO_INCREMENT de la tabla `t_familias`
--
ALTER TABLE `t_familias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;
--
-- AUTO_INCREMENT de la tabla `t_fuentes`
--
ALTER TABLE `t_fuentes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;
--
-- AUTO_INCREMENT de la tabla `t_registros`
--
ALTER TABLE `t_registros`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=428544;
--
-- AUTO_INCREMENT de la tabla `t_tipos`
--
ALTER TABLE `t_tipos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `t_especies`
--
ALTER TABLE `t_especies`
  ADD CONSTRAINT `t_especie_id_familia` FOREIGN KEY (`familia_id`) REFERENCES `t_familias` (`id`),
  ADD CONSTRAINT `t_especies_id_tipo` FOREIGN KEY (`tipo_id`) REFERENCES `t_tipos` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `t_registros`
--
ALTER TABLE `t_registros`
  ADD CONSTRAINT `t_registros_ibfk_1` FOREIGN KEY (`fuente_id`) REFERENCES `t_fuentes` (`id`),
  ADD CONSTRAINT `t_registros_ibfk_2` FOREIGN KEY (`especie_id`) REFERENCES `t_especies` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
