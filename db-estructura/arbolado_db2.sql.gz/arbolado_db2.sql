-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 03-12-2016 a las 18:46:03
-- Versión del servidor: 10.1.16-MariaDB
-- Versión de PHP: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `arbolado_db2`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `t_especies`
--

DROP TABLE IF EXISTS `t_especies`;
CREATE TABLE `t_especies` (
  `id` int(11) NOT NULL,
  `nombre_cientifico` varchar(255) NOT NULL DEFAULT '',
  `nombre_comun` varchar(255) NOT NULL DEFAULT '',
  `familia_id` int(11) NOT NULL,
  `follaje_tipo` varchar(255) NOT NULL DEFAULT '',
  `origen` varchar(255) NOT NULL DEFAULT '',
  `region_pampeana` tinyint(1) NOT NULL DEFAULT '0',
  `region_nea` tinyint(1) NOT NULL DEFAULT '0',
  `region_noa` tinyint(1) NOT NULL DEFAULT '0',
  `region_cuyana` tinyint(1) NOT NULL DEFAULT '0',
  `region_patagonica` tinyint(1) NOT NULL DEFAULT '0',
  `procedencia_exotica` varchar(50) DEFAULT NULL,
  `icono` varchar(50) DEFAULT NULL,
  `img_completo` int(1) DEFAULT NULL,
  `img_hoja` int(1) DEFAULT NULL,
  `img_flor` int(1) DEFAULT NULL,
  `img_fruto` int(1) DEFAULT NULL,
  `descripcion` text,
  `medicinal` text,
  `comestible` text,
  `perfume` tinyint(1) DEFAULT NULL,
  `abejas` tinyint(1) DEFAULT NULL,
  `mariposas` tinyint(1) DEFAULT NULL,
  `url` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `t_familias`
--

DROP TABLE IF EXISTS `t_familias`;
CREATE TABLE `t_familias` (
  `id` int(11) NOT NULL,
  `familia` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `t_fuentes`
--

DROP TABLE IF EXISTS `t_fuentes`;
CREATE TABLE `t_fuentes` (
  `id` int(11) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `descripcion` text,
  `email` varchar(50) DEFAULT NULL,
  `facebook` varchar(50) DEFAULT NULL,
  `twitter` varchar(50) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `t_registros`
--

DROP TABLE IF EXISTS `t_registros`;
CREATE TABLE `t_registros` (
  `id` int(11) NOT NULL,
  `arbol_id` int(11) NOT NULL DEFAULT '0',
  `especie_id` int(11) NOT NULL,
  `lat` float(12,10) NOT NULL,
  `lng` float(12,10) NOT NULL,
  `localidad` varchar(50) NOT NULL DEFAULT 'CABA',
  `calle` varchar(255) DEFAULT NULL,
  `calle_altura` int(11) DEFAULT NULL,
  `espacio_verde` varchar(255) DEFAULT NULL,
  `altura` int(11) DEFAULT NULL,
  `diametro` int(11) DEFAULT NULL,
  `inclinacion` int(11) DEFAULT NULL,
  `estado_fitosanitario` varchar(50) DEFAULT NULL,
  `estapa_desarrollo` varchar(50) DEFAULT NULL,
  `fuente_id` int(11) NOT NULL,
  `fecha_creacion` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `t_especies`
--
ALTER TABLE `t_especies`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `url` (`url`),
  ADD KEY `id_especie` (`id`),
  ADD KEY `id_familia` (`familia_id`);

--
-- Indices de la tabla `t_familias`
--
ALTER TABLE `t_familias`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `t_fuentes`
--
ALTER TABLE `t_fuentes`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `t_registros`
--
ALTER TABLE `t_registros`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_individuo` (`id`),
  ADD KEY `arbol_id` (`arbol_id`),
  ADD KEY `id_especie` (`especie_id`),
  ADD KEY `id_usuario` (`fuente_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `t_especies`
--
ALTER TABLE `t_especies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10005;
--
-- AUTO_INCREMENT de la tabla `t_familias`
--
ALTER TABLE `t_familias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;
--
-- AUTO_INCREMENT de la tabla `t_fuentes`
--
ALTER TABLE `t_fuentes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT de la tabla `t_registros`
--
ALTER TABLE `t_registros`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=424384;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `t_especies`
--
ALTER TABLE `t_especies`
  ADD CONSTRAINT `t_especies_ibfk_1` FOREIGN KEY (`familia_id`) REFERENCES `t_familias` (`id`);

--
-- Filtros para la tabla `t_registros`
--
ALTER TABLE `t_registros`
  ADD CONSTRAINT `t_registros_ibfk_1` FOREIGN KEY (`especie_id`) REFERENCES `t_especies` (`id`),
  ADD CONSTRAINT `t_registros_ibfk_2` FOREIGN KEY (`fuente_id`) REFERENCES `t_fuentes` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
